package com.example.zenith;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MessageActivity extends AppCompatActivity {

    public String heading = getIntent().getStringExtra("heading");
    public String body = getIntent().getStringExtra("body");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        TextView one = findViewById(R.id.head);
        TextView two = findViewById(R.id.subhead);
        TextView three = findViewById(R.id.body);
        showHardcodedAlertDialog();

        one.setText(heading);
        two.setText(heading);
        three.setText(body);

        ImageButton button = findViewById(R.id.imageButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    showHardcodedAlertDialog();

            }
        });

    }

    private void showHardcodedAlertDialog() {
        // Create an AlertDialog.Builder instance
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Set the title and message for the alert dialog
        builder.setTitle("WARNING!");
        builder.setMessage("This is a otp message. do not share it with anyone except the site it is meant for.If u did not ask for an opt, ignore this message.");

        // Set positive button
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

}