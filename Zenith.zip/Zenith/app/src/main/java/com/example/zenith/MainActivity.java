package com.example.zenith;

import android.Manifest;
import android.content.res.Resources;
import android.os.Bundle;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.util.SparseArray;
import android.view.ViewTreeObserver;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private LinearLayout linearLayout1;
    private SparseArray<String> idToCustomIdMap = new SparseArray<>();
    private int counter = 1;
    private LinearLayout linearLayout2;
    private TextView originalTextView1;
    private TextView originalTextView2;
    private ScrollView scrollView1;
    private ScrollView scrollView2;
    private ImageView originalImageView;
    private BroadcastReceiver smsReceiver;
    private static final int READ_SMS_PERMISSION_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayout1 = findViewById(R.id.linearLayout1);
        linearLayout2 = findViewById(R.id.linearLayout2);
        originalTextView1 = findViewById(R.id.originalTextView1);
        originalTextView2 = findViewById(R.id.originalTextView2);
        originalImageView = findViewById(R.id.originalImageView);

        scrollView1 = findViewById(R.id.scrollView1);
        scrollView2 = findViewById(R.id.scrollView2);

        // Add a scroll change listener to the first ScrollView
        scrollView1.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                // Scroll the second ScrollView by the same amount
                scrollView2.scrollTo(scrollX, scrollY);
            }
        });

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_SMS}, READ_SMS_PERMISSION_CODE);
        } else {
            readSms();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == READ_SMS_PERMISSION_CODE)
        {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                readSms();
            }
        }
    }
    private void readSms(){
        ContentResolver contentResolver = getContentResolver();
        Cursor cursor = contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                null,
                null,
                null,
                null
        );
        if(cursor != null && cursor.moveToFirst())
        {
            do{
                String address = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));
                String body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY));
                TextView newTextView1 = new TextView(this);
                TextView newTextView2 = new TextView(this);
                ImageView newImageView = new ImageView(this);
                newImageView.setImageDrawable(originalImageView.getDrawable());
                newImageView.setAdjustViewBounds(originalImageView.getAdjustViewBounds());
                newImageView.setScaleType(originalImageView.getScaleType());
                newImageView.setLayoutParams(originalImageView.getLayoutParams());
                newTextView1.setTextColor(originalTextView1.getCurrentTextColor());
                newTextView1.setText(address);
                newTextView1.setTypeface(originalTextView1.getTypeface());
                setCustomId(newTextView2,"two" + counter);
                newTextView2.setClickable(true);
                newTextView1.setClickable(true);
                newTextView1.setLayoutParams(originalTextView1.getLayoutParams());
                newTextView2.setTextColor(originalTextView2.getCurrentTextColor());
                newTextView2.setTypeface(originalTextView2.getTypeface());
                newTextView2.setLayoutParams(originalTextView2.getLayoutParams());
                newTextView1.setOnClickListener(this::checkId);
                newTextView2.setOnClickListener(this::checkId);
                setCustomId(newTextView1,"one" + counter);
                newTextView2.setText(body);
                linearLayout1.addView(newImageView, 0);
                linearLayout2.addView(newTextView2, 0);
                linearLayout2.addView(newTextView1, 0);

                System.out.println("Sender: " + address + "\nMessage: " + body);
                counter++;
            } while(cursor.moveToNext());
        }
        if(cursor != null)
        {
            cursor.close();
        }
    }
    public void checkId(View view)
    {
        int idi = view.getId();
        TextView myTextView = findViewById(idi);
        Intent intent = new Intent(MainActivity.this, MessageActivity.class);
        startActivity(intent);
        String id = getCustomId(myTextView);
        if(id.split(",")[0].equals("one")){
            intent.putExtra("heading", myTextView.getText().toString());
            int iid = getIntegerId("two," + id.split(",")[1].toString());
            TextView two = findViewById(iid);
            intent.putExtra("body", two.getText().toString());
        } else{
            intent.putExtra("body", myTextView.getText().toString());
            int iid = getIntegerId("one," + id.split(",")[1].toString());
            TextView three = findViewById(iid);
            intent.putExtra("heading", three.getText().toString());
        }

    }

    private void setCustomId(TextView textView, String customId) {
        // Set a tag to represent a custom ID
        textView.setTag(customId);

        // Save the mapping between integer ID and custom ID
        int integerId = textView.getId();
        idToCustomIdMap.put(integerId, customId);
    }

    private String getCustomId(TextView textView) {
        // Retrieve the custom ID from the tag
        Object tag = textView.getTag();
        return (tag != null) ? tag.toString() : null;
    }

    private int getIntegerId(String customId) {
        // Retrieve the integer ID based on the custom ID
        for (int i = 0; i < idToCustomIdMap.size(); i++) {
            if (customId.equals(idToCustomIdMap.valueAt(i))) {
                return idToCustomIdMap.keyAt(i);
            }
        }
        return -1; // Not found
    }
}