package com.example.zenith;

import android.content.Intent;
import android.os.Bundle;
import com.example.zenith.R;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.zenith.databinding.ActivitySplashBinding;


import android.content.Intent;
import android.os.Bundle;
import com.example.zenith.R;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.zenith.databinding.ActivitySplashBinding;

        public class splashActivity extends AppCompatActivity {

            private Button button;
            EditText inputPass;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_splash);
                button = findViewById(R.id.button);
                inputPass = findViewById(R.id.textiPassword);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String text = inputPass.getText().toString();
                        if (text.equals("140508")) {
                            Intent intent = new Intent(splashActivity.this, MainActivity.class);

                            // Start the SecondActivity
                            startActivity(intent);
                        }
                    }
                });


            }
        }